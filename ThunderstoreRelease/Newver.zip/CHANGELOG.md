# Lee: Hyperreal - A Character Mod for Risk of Rain 2
## Changelog
- 1.0.1
    - Fixing soundbank from not loading. 
- 1.0.0
    - Initial Release!